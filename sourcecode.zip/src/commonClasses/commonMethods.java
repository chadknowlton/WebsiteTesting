package commonClasses;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class commonMethods {
	public void login(WebDriver driver, String user, String pass)
	{
		  driver.findElement(By.id("username-input")).sendKeys(user);
	      driver.findElement(By.id("password-input")).sendKeys(pass);
	      driver.findElement(By.xpath("//button[text()='Submit']")).click();
	}
}
