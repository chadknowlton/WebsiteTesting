package commonClasses;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;



public class commonMethods {
	
	private static final String BAD_USER = "test";
	private static final String GOOD_USER = "chadknowlton@unomaha.edu";

	private static final String BAD_PASS = "NewPassword";
	private static final String GOOD_PASS = "Password";
	
	public String goodPass()
	{
		return GOOD_PASS;
	}
	public String badPass()
	{
		return BAD_PASS;
	}
	public String goodUser()
	{
		return GOOD_USER;
	}
	public String badUser()
	{
		return BAD_USER;
	}
	
	public void login(WebDriver driver, String user, String pass)
	{
		  driver.findElement(By.id("username-input")).clear();
		  driver.findElement(By.id("password-input")).clear();
		  driver.findElement(By.id("username-input")).sendKeys(user);
	      driver.findElement(By.id("password-input")).sendKeys(pass);
	      driver.findElement(By.xpath("//button[text()='Submit']")).click();
	}
	
	public void logout(WebDriver driver)
	{
	      driver.findElement(By.xpath("//button[text()='Logout']")).click();
	}
}
