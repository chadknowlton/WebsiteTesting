package tests;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import commonClasses.commonMethods;

public class BuyTest {
	private WebDriver driver;
	   private commonMethods common = new commonMethods();
	   
	   
	   @Before
	   public void setUp() throws Exception {
	      System.setProperty("webdriver.chrome.driver", //
	    		  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	      driver = new ChromeDriver();
	      // driver = new FirefoxDriver();
	      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   }

	   @Test
	   public void test() throws Exception {


		      driver.get("http://group4830-project-deployment.s3-website-us-east-1.amazonaws.com/");
		      common.login(driver, common.goodUser(), common.goodPass());
		      Thread.sleep(100);
		      driver.findElement(By.linkText("Buy")).click();
		      
		      //Add Buy Offer Section
		      //Search and Cancel
		      searchBook("9780486485812");
		      String title = driver.findElement(By.xpath("//p[text()='Title:']/../following-sibling::div/p")).getText();
		      Assert.assertEquals("Titles should be equal, but are not", "Data Structures & Algorithm Analysis in Java", title);
		      driver.findElement(By.xpath("//button[text()='Cancel']")).click();
		      boolean selectBook = driver.findElement(By.xpath("//button[text()='Select Book']")).isDisplayed();
		      Assert.assertTrue("Select Book Button should be present, but is not", selectBook);
		      
		      searchBook("9780486485812");
		      driver.findElement(By.xpath("//button[text()='View More Details']")).click();
		      boolean moreDetailsModal = driver.findElement(By.xpath("//header[@id='modal-add-account___BV_modal_header_']")).isDisplayed();
		      Assert.assertTrue("More Details Modal was not present", moreDetailsModal);
		      Thread.sleep(1000);
		      driver.findElement(By.xpath("//button[text()='Close']")).click();
		      driver.findElement(By.xpath("//button[text()='Cancel']")).click();
		      
		      searchBook("9780486485812");
		      driver.findElement(By.xpath("//button[text()='View More Details']")).click();
		      driver.findElement(By.xpath("//footer[@id='modal-add-account___BV_modal_footer_']/button[text()='Select Book']")).click();
			  boolean feedBack = driver.findElement(By.xpath("//div[@class='AddBuyOffer']//fieldset//div[text()='ISBN']/../../..//div[text()='Thank You']")).isDisplayed();
			  Assert.assertTrue("Was not equal as expected", feedBack);
			  
			  JavascriptExecutor jse = (JavascriptExecutor)driver;
			  jse.executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight));");

			  Thread.sleep(1000);
			  
			  //Set Price
			  setPrice();
			  
			  //Set Quality
			  setQuality();
			  
			  //Submit
			  driver.findElement(By.xpath("//button[text()='Submit']")).click();
			  Thread.sleep(1000);
			  String bookText = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//table/tbody/tr[1]/td[1]")).getText();
			  Assert.assertEquals("Book text did not match", "Data Structures & Algorithm Analysis in Java", bookText);
			  
			  //Add another book for queries
			  searchBook("9780133943030");
		      driver.findElement(By.xpath("//button[text()='Select Book']")).click();
			  setPrice();
			  setQuality();
			  driver.findElement(By.xpath("//button[text()='Submit']")).click();
			  
			  
			  //My Buy Offers Section
			  //View Button
			  driver.findElement(By.xpath("//table//tbody/tr[1]/td[4]/button[text()='Edit']")).click();
		      moreDetailsModal = driver.findElement(By.xpath("//div[@id='modal-edit-details']//header")).isDisplayed();
		      Assert.assertTrue("More Details Modal was not present", moreDetailsModal);
		      driver.findElement(By.xpath("//button[text()='Close']")).click();
		      
		      //Edit Button
		      driver.findElement(By.xpath("//table//tbody/tr[1]/td[4]/button[text()='Edit']")).click();
		      driver.findElement(By.xpath("//div[@class='modal-dialog modal-lg']//input[@id='price-input']")).clear();
		      driver.findElement(By.xpath("//div[@class='modal-dialog modal-lg']//input[@id='price-input']")).sendKeys("30");
		      driver.findElement(By.xpath("//div[@class='modal-dialog modal-lg']//select")).click();
		      driver.findElement(By.xpath("//div[@class='modal-dialog modal-lg']//select/option[text()='Poor Quality']")).click();
		      Thread.sleep(1000);
		      Thread.sleep(1000);
		      driver.findElement(By.xpath("//button[text()='Update']")).click();
		      Thread.sleep(1000);
		      
		      //Search
		      driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset//input[contains(@placeholder, 'Enter a Book')]")).sendKeys("Software Engineering");
		      Thread.sleep(1000);
		      bookText = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//table//tbody/tr[1]/td[1]")).getText();
			  Assert.assertEquals("Book text did not match", "Software Engineering", bookText);
			  driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();
			  String searchFieldText = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset//input[contains(@placeholder, 'Enter a Book')]")).getText();
			  Assert.assertEquals("Should be empty, but is not", "", searchFieldText);
			  
			  //Search by Price
			  driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//div[@role='radiogroup']//span[text()='Price']/..")).click();
			  Thread.sleep(1000);
		      driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset//input[contains(@placeholder, 'Enter a Price')]")).sendKeys("30");
		      bookText = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//table//tbody/tr[1]/td[1]")).getText();
				 Assert.assertEquals("Book text did not match", "Data Structures & Algorithm Analysis in Java", bookText);
			  driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();

			  //Search By Quality
			  driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//div[@role='radiogroup']//span[text()='Quality']/..")).click();
		      driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset//select")).click();
		      driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset//select//option[text()='Used']")).click();
		      bookText = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//table//tbody/tr[1]/td[1]")).getText();
			  Assert.assertEquals("Book text did not match", "Software Engineering", bookText);
			  driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();
			  
			  //Delete Entries
			  driver.findElement(By.xpath("//table//tbody/tr[1]/td[4]/button[text()='Delete']")).click();
			  Thread.sleep(1000);
			  driver.findElement(By.xpath("//table//tbody/tr[1]/td[4]/button[text()='Delete']")).click();
			  String noEntries = driver.findElement(By.xpath("//div[@class='displayOurBuyOffers']//table//tbody/tr[1]//div//div")).getText();
			  Assert.assertEquals("There are Entries unexpectedly", "There are no records to show", noEntries);
			  
			  // Other's Buy Offers Section
			  //Title Search
			  driver.findElement(By.xpath("//input[@placeholder='Enter a Book Title to Search']")).sendKeys("Calculus");
			  Thread.sleep(1000);
			  title = driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//table//tbody//tr[1]//td[1]")).getText();
			  Assert.assertEquals("Expected Book was not present", "Calculus", title);
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();
			  searchFieldText = driver.findElement(By.xpath("//input[@placeholder='Enter a Book Title to Search']")).getText();
			  Assert.assertEquals("Should be empty, but is not", "", searchFieldText);
			  
			  //Price Search
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//div[@role='radiogroup']//span[text()='Price']/..")).click();
		      driver.findElement(By.xpath("//input[@placeholder='Enter a Price (Less than or Equal)']")).sendKeys("200");
		      title = driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//table//tbody//tr[1]//td[1]")).getText();
			  Assert.assertEquals("Expected Book was not present", "Calculus", title);
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();
			  
			  //Quality Search
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//div[@role='radiogroup']//span[text()='Quality']/..")).click();
		      driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//fieldset//select")).click();
		      driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//fieldset//select//option[text()='Brand New']")).click();
		      title = driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//table//tbody//tr[1]//td[1]")).getText();
			  Assert.assertEquals("Expected Book was not present", "Calculus", title);
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//fieldset[@class='form-group mb-2']//button[text()='Clear']")).click();
			  
			  //Book View
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//table//tbody//tr[1]//td[4]//button[text()='View']")).click();
			  Thread.sleep(1000);
			  boolean modalPresent = driver.findElement(By.xpath("//header[@id='modal-view-book___BV_modal_header_']")).isDisplayed();
			  Assert.assertTrue("Modal Should be Present, but is not", modalPresent);
			  driver.findElement(By.xpath("//button[text()='Close']")).click();
			  
			  //Book Buy
			  driver.findElement(By.xpath("//div[@class='displayOthersBuyOffers']//table//tbody//tr[1]//td[4]//button[text()='Sell']")).click();
			  Thread.sleep(1000);
			  modalPresent = driver.findElement(By.id("modal-sell-details___BV_modal_header_")).isDisplayed();
			  Assert.assertTrue("Modal Should be Present, but is not", modalPresent);
			  
			  //Set Book Entries
			  driver.findElement(By.xpath("//label[text()='No time selected']/..")).click();
			  Thread.sleep(2000);
			  driver.findElement(By.xpath("//div[@title='Hours']//button[@aria-label='Decrement']//div//*")).click();
			  driver.findElement(By.xpath("//div[@title='Hours']//button[@aria-label='Decrement']//div//*")).click();

			  driver.findElement(By.xpath("//div[@title='Minutes']//button[@aria-label='Decrement']//div//*")).click();
			  driver.findElement(By.xpath("//div[@title='Minutes']//button[@aria-label='Decrement']//div//*")).click();
			  
			  driver.findElement(By.xpath("//label[text()='No date selected']")).click();
			  Thread.sleep(1000);
			  driver.findElement(By.xpath("//div[@class='dropdown-menu show']//div//div[contains(@aria-label, 'Today')]")).click();
			  
			  driver.findElement(By.id("street-input")).sendKeys("5000 UNO Street");
			  driver.findElement(By.id("city-input")).sendKeys("Omaha");
			  driver.findElement(By.id("state-input")).sendKeys("Nebraska");
			  driver.findElement(By.id("zipcode-input")).sendKeys("12345");
			  driver.findElement(By.id("comments-input")).sendKeys("Sample Comment for the BuyTest test");
			  driver.findElement(By.xpath("//div[@id='modal-sell-details___BV_modal_content_']//button[text()='Submit']")).click();

			  common.logout(driver);
			  common.login(driver, common.sampleUser(), common.samplePass());
			  driver.findElement(By.xpath("//button[text()='Reject']")).click();
			  String message = driver.findElement(By.xpath("//div[@role='alert']//div")).getText();
			  Assert.assertEquals("Message was not matching", "There are no records to show", message);
			  driver.close();
			  //finished
		   }

		private void setPrice() {
			driver.findElement(By.id("price-input")).sendKeys("20");
			boolean feedBack = driver.findElement(By.xpath("//div[@class='AddBuyOffer']//fieldset//div[text()='Price']/../../..//div[text()='Thank You']")).isDisplayed();
			Assert.assertTrue("Was not equal as expected", feedBack);
		}

		private void setQuality() {
			driver.findElement(By.id("quality")).click();
			  driver.findElement(By.xpath("//select[@id='quality']//option[text()='Used']")).click();
			  boolean feedBack = driver.findElement(By.xpath("//div[@class='AddBuyOffer']//fieldset//div[text()='Quality']/../../..//div[text()='Thank You']")).isDisplayed();
			  Assert.assertTrue("Was not equal as expected", feedBack);
		}

		private void searchBook(String isbn) {
			  driver.findElement(By.xpath("//button[text()='Select Book']")).click();
			  driver.findElement(By.id("isbn-input")).sendKeys(isbn);
		      driver.findElement(By.xpath("//button[text()='Search']")).click();
		      
		}
}
