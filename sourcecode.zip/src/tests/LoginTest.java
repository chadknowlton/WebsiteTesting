package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import commonClasses.commonMethods;

public class LoginTest {
   private WebDriver driver;
   private boolean acceptNextAlert = true;
   private StringBuffer verificationErrors = new StringBuffer();

   private static final String BAD_USER = "test";
   private static final String GOOD_USER = "chadknowlton@unomaha.edu";
   
   private static final String BAD_PASS = "x";
   private static final String GOOD_PASS = "Password";
   
   private commonMethods common = new commonMethods();
   
   
   @Before
   public void setUp() throws Exception {
      System.setProperty("webdriver.chrome.driver", //
    		  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
      driver = new ChromeDriver();
      // driver = new FirefoxDriver();
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   @Test
   public void testClassSearch() throws Exception {
      driver.get("http://group4830-project-deployment.s3-website-us-east-1.amazonaws.com/");
      
      //Bad Login
      common.login(driver, BAD_USER, BAD_PASS);
      Thread.sleep(100);
      boolean errorMsg = driver.findElement(By.xpath("//div[@role='alert' and text()='Error Logging In, Check details']")).isDisplayed();
      Assert.assertTrue("Error message should be present, but is not", errorMsg);
      
      //Good Login
      common.login(driver, GOOD_USER, GOOD_PASS);
      Thread.sleep(100);
      String titleText = driver.findElement((By.xpath("//h3"))).getText();
      Assert.assertEquals("Welcome Text should be equal, but is not", "Welcome Chad Knowlton", titleText);
      System.out.println("Successfully verified the login screen");
      
      driver.findElement(By.xpath("//button[text()='Logout']")).click();
      titleText = driver.findElement((By.xpath("//h1"))).getText();
      Assert.assertEquals( "Welcome Text should be equal, but is not", "The Book Worms", titleText);
      System.out.println("Finished the Test");
      
      driver.close();
     
   }

   /**
   @After
   public void tearDown() throws Exception {
      driver.quit();
      String verificationErrorString = verificationErrors.toString();
      if (!"".equals(verificationErrorString)) {
         fail(verificationErrorString);
      }
   }

   private boolean isElementPresent(By by) {
      try {
         driver.findElement(by);
         return true;
      } catch (NoSuchElementException e) {
         return false;
      }
   }

   private boolean isAlertPresent() {
      try {
         driver.switchTo().alert();
         return true;
      } catch (NoAlertPresentException e) {
         return false;
      }
   }

   private String closeAlertAndGetItsText() {
      try {
         Alert alert = driver.switchTo().alert();
         String alertText = alert.getText();
         if (acceptNextAlert) {
            alert.accept();
         } else {
            alert.dismiss();
         }
         return alertText;
      } finally {
         acceptNextAlert = true;
      }
   }
   */
}
