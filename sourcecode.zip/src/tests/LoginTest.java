package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import commonClasses.commonMethods;

public class LoginTest {
   private WebDriver driver;
   private commonMethods common = new commonMethods();
   
   
   @Before
   public void setUp() throws Exception {
      System.setProperty("webdriver.chrome.driver", //
    		  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
      driver = new ChromeDriver();
      // driver = new FirefoxDriver();
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   @Test
   public void test() throws Exception {
      driver.get("http://group4830-project-deployment.s3-website-us-east-1.amazonaws.com/");
      
      //Bad Login
      common.login(driver, common.badUser(), common.badPass());
      Thread.sleep(100);
      boolean errorMsg = driver.findElement(By.xpath("//div[@role='alert' and text()='Error Logging In, Check details']")).isDisplayed();
      Assert.assertTrue("Error message should be present, but is not", errorMsg);
      
      //Good Login
      boolean buttonEnabled = driver.findElement(By.xpath("//button[text()='Submit']")).isEnabled();
      Assert.assertFalse("Button Should be Disabled, but is not", buttonEnabled);
      common.login(driver, common.goodUser(), common.goodPass());
      Thread.sleep(100);
      String titleText = driver.findElement((By.xpath("//h3"))).getText();
      Assert.assertEquals("Welcome Text should be equal, but is not", "Welcome Chad Knowlton", titleText);
      System.out.println("Successfully verified the login screen");
      common.logout(driver);
      titleText = driver.findElement((By.xpath("//h1"))).getText();
      Assert.assertEquals( "Welcome Text should be equal, but is not", "The Book Worms", titleText);
      System.out.println("Finished the Login Test");
      
      driver.close();
     
   }
}