package tests;

public class RunAll {
	   
	public static void main(String[] args)
	{
		AboutTest aboutTest = new AboutTest();
		LoginTest loginTest = new LoginTest();
		SettingsTest settingsTest = new SettingsTest();
		BuyTest buyTest = new BuyTest();
		SellTest sellTest = new SellTest();
		HomeTest homeTest = new HomeTest();
		
		try
		{
			loginTest.setUp();
			loginTest.test();
			
			aboutTest.setUp();
			aboutTest.test();
			
			settingsTest.setUp();
			settingsTest.test();
			
			buyTest.setUp();
			buyTest.test();
			
			sellTest.setUp();
			sellTest.test();
			
			homeTest.setUp();
			homeTest.test();
		}
		catch (Exception e)
		{
			System.out.println("Unknown Error Occured");
		}
		finally
		{
			System.out.println("Finished Running All Tests");
		}
	}
}
