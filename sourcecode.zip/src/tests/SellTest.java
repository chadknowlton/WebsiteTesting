package tests;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import commonClasses.commonMethods;

public class SellTest {
	private WebDriver driver;
	   private commonMethods common = new commonMethods();
	   
	   
	   @Before
	   public void setUp() throws Exception {
	      System.setProperty("webdriver.chrome.driver", //
	    		  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	      driver = new ChromeDriver();
	      // driver = new FirefoxDriver();
	      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   }

	   @Test
	   public void test() throws Exception {
	      driver.get("http://group4830-project-deployment.s3-website-us-east-1.amazonaws.com/");

	      common.login(driver, common.goodUser(), common.goodPass());
	      Thread.sleep(100);
	      driver.findElement(By.linkText("Sell")).click();
	   }
}
