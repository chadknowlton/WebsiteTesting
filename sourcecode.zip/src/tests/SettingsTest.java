package tests;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import commonClasses.commonMethods;

public class SettingsTest {
	private WebDriver driver;
	   private commonMethods common = new commonMethods();
	   
	   
	   @Before
	   public void setUp() throws Exception {
	      System.setProperty("webdriver.chrome.driver", //
	    		  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	      driver = new ChromeDriver();
	      // driver = new FirefoxDriver();
	      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   }

	   @Test
	   public void test() throws Exception {
	      driver.get("http://group4830-project-deployment.s3-website-us-east-1.amazonaws.com/");

	      common.login(driver, common.goodUser(), common.goodPass());
	      Thread.sleep(100);
	      driver.findElement(By.linkText("Settings")).click();
	      boolean buttonEnabled = driver.findElement(By.xpath("//button[text()='Update Password']")).isEnabled();
	      Assert.assertFalse("Button Should be Disabled, but is not", buttonEnabled);
	      driver.findElement(By.id("oldpassword-input")).sendKeys(common.goodPass());
	      driver.findElement(By.id("zipcode-input")).sendKeys(common.badPass());
	      driver.findElement(By.id("repeat-input")).sendKeys(common.badPass());
	      driver.findElement(By.xpath("//button[text()='Update Password']")).click();
	      common.logout(driver);
	      common.login(driver, common.goodUser(), common.goodPass());
	      Thread.sleep(100);
	      boolean errorMsg = driver.findElement(By.xpath("//div[@role='alert' and text()='Error Logging In, Check details']")).isDisplayed();
	      Assert.assertTrue("Error message should be present, but is not", errorMsg);
	      common.login(driver, common.goodUser(), common.badPass());
	      driver.findElement(By.linkText("Settings")).click();
	      driver.findElement(By.id("oldpassword-input")).sendKeys(common.badPass());
	      driver.findElement(By.id("zipcode-input")).sendKeys(common.goodPass());
	      driver.findElement(By.id("repeat-input")).sendKeys(common.goodPass());
	      driver.findElement(By.xpath("//button[text()='Update Password']")).click();
	      
	      System.out.println("Finished the Settings Test");
	      driver.close();
	   }
}
